#pragma once

void stergereSpatii(char* str);
double putere(int a, int b);
double radical(int a, int b);